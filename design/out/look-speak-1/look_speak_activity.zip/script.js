
/* Simple interactivity for demo */
const btnSpeak = document.getElementById('btnSpeak');
btnSpeak?.addEventListener('click', () => {
  // A tiny 'beep' using WebAudio so the button feels alive.
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type = 'sine'; o.frequency.value = 880;
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
    o.start(); o.stop(ctx.currentTime + 0.25);
  } catch(e) {}
});

const btnMic = document.getElementById('btnMic');
let mediaStream, mediaRecorder;
btnMic?.addEventListener('click', async () => {
  const active = btnMic.classList.toggle('recording');
  btnMic.setAttribute('aria-pressed', String(active));

  if (active) {
    // Try to start mic via MediaDevices (may ask permission in browsers)
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(mediaStream);
        mediaRecorder.start();
      } catch (err) {
        console.warn('Mic unavailable:', err);
      }
    }
  } else {
    try { mediaRecorder?.stop(); mediaStream?.getTracks().forEach(t => t.stop()); } catch(e){}
  }
});

// Hint button toggles a subtle emphasis on answer
const btnHint = document.getElementById('btnHint');
const answer = document.getElementById('answerText');
btnHint?.addEventListener('click', () => {
  const expanded = btnHint.getAttribute('aria-expanded') === 'true';
  btnHint.setAttribute('aria-expanded', String(!expanded));
  answer.style.color = expanded ? '#0E1633' : '#1633A0';
  answer.style.textDecoration = expanded ? 'none' : 'underline';
});

// Example: update price dynamically and auto-grow box
// To test: setPrice('135,000', '원입니다.');
function setPrice(numberText, suffixText){
  const num = document.querySelector('.price-text .num');
  const suf = document.querySelector('.price-text .suffix');
  if (num) num.textContent = numberText;
  if (suf) suf.textContent = suffixText;
}
window.setPrice = setPrice;
